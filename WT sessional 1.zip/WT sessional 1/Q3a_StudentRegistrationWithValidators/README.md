# Q3a (OR): Student Registration with Validators

This ASP.NET Web Forms page provides a student registration form with:

- RegularExpressionValidator for email
- CompareValidator for password confirmation
- CustomValidator for age (must be 18+)

Open `Q3a_StudentRegistrationWithValidators.aspx` in your browser to test.
