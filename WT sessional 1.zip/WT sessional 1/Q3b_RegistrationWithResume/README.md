# Q3b: Registration with Resume Upload

This ASP.NET Web Forms page provides a registration form with PDF resume upload (max 10KB). All details are displayed in a label after registration.

Open `Q3b_RegistrationWithResume.aspx` in your browser to test.
