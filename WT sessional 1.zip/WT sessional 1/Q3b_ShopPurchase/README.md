# Q3b (OR): Shop Purchase

This ASP.NET Web Forms page provides a shop purchase form:

- CheckBoxList for items (with price in value)
- Total price auto-calculated in a readonly TextBox
- Button to display purchased items and total paid

Open `Q3b_ShopPurchase.aspx` in your browser to test.
