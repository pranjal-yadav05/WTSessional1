# Q2a: ImageMap Hotspot Example

This ASP.NET Web Forms page demonstrates the use of different hotspot modes (Circle, Rectangle, Polygon) in an ImageMap control. Clicking on the sun, mountain, or river displays the name of the entity.

- Add an image named `sun_mountain_river.jpg` to your project root for the hotspots to align.
- Open `Q2a_ImageMap.aspx` in your browser to test.
