# Q2c: Dynamic Table Generator

This ASP.NET Web Forms page lets you select the number of rows/columns and a control type (TextBox, HyperLink, LinkButton) to dynamically generate a table.

Open `Q2c_DynamicTable.aspx` in your browser to test.
