# Q2b: Custom Calendar

This ASP.NET Web Forms page demonstrates a custom calendar:

- Monday is a holiday (red background)
- Event (21st-25th Aug 2024) is highlighted and not selectable
- Holidays (15th Aug: Independence Day, 19th Aug: Rakshabandhan) are marked
- Calendar week starts from Tuesday

Open `Q2b_CustomCalendar.aspx` in your browser to test.
