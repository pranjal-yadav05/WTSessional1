# Q3a: Master Page with Department Faculty List

This ASP.NET Web Forms solution uses a master page for a common header, footer, and left panel (RadioButtonList for department selection). The right panel (content page) displays a faculty list for the selected department.

- Open `Q3a_FacultyList.aspx` in your browser to test.
- Department selection updates the faculty list dynamically.
